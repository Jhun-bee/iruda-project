** 가상환경 **
conda create -n iruda310 python==3.10

** iruda-project 한폴더에 tree **


가상환경은 중앙 - 모든 작업은 iruda-project안에서 진행

app.py 실행 후

http://localhost:5000
웹으로 실행