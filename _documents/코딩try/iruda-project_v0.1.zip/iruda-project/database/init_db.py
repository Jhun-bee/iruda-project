import sqlite3
import os

def init_database():
    """SQLite 데이터베이스 초기화"""
    
    # 데이터베이스 폴더가 없으면 생성
    os.makedirs('database', exist_ok=True)
    
    # 데이터베이스 연결
    conn = sqlite3.connect('database/iruda.db')
    cursor = conn.cursor()
    
    # 사용자 테이블 생성
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            name TEXT NOT NULL,
            age INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 사용자 프로필 테이블
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            housing_status TEXT,
            income_level TEXT,
            education_level TEXT,
            employment_status TEXT,
            support_needs TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # 로드맵 테이블
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS roadmaps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT NOT NULL,
            description TEXT,
            priority_areas TEXT,
            timeline TEXT,
            status TEXT DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # 정책 테이블
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS policies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT,
            description TEXT,
            eligibility_criteria TEXT,
            application_url TEXT,
            is_active BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 샘플 정책 데이터 삽입
    sample_policies = [
        ('청년 주거급여', '주거', '만 19~29세 청년을 대상으로 한 주거비 지원', 
         '{"age_min": 19, "age_max": 29, "income_criteria": "중위소득 46% 이하"}',
         'https://www.gov.kr/portal/service/serviceInfo/PTR000050463'),
        
        ('청년 취업 성공패키지', '취업', '저소득 청년층 취업지원 및 직업훈련 프로그램',
         '{"age_min": 18, "age_max": 34, "employment_status": "구직자"}',
         'https://www.work.go.kr/youngjob'),
        
        ('청년 창업지원금', '창업', '청년 창업자를 위한 초기 창업비용 지원',
         '{"age_min": 18, "age_max": 39, "business_experience": "3년 이하"}',
         'https://www.k-startup.go.kr'),
    ]
    
    cursor.executemany('''
        INSERT OR IGNORE INTO policies 
        (name, category, description, eligibility_criteria, application_url)
        VALUES (?, ?, ?, ?, ?)
    ''', sample_policies)
    
    conn.commit()
    conn.close()
    
    print("✅ 데이터베이스가 성공적으로 초기화되었습니다!")

if __name__ == '__main__':
    init_database()