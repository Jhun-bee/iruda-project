from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import json
import os
from dotenv import load_dotenv
import openai

# 환경변수 로드
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-change-this'

# Flask-Login 설정
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# OpenAI API 키 설정
openai.api_key = os.getenv('OPENAI_API_KEY')

class User(UserMixin):
    def __init__(self, id, email, name):
        self.id = id
        self.email = email
        self.name = name

@login_manager.user_loader
def load_user(user_id):
    conn = sqlite3.connect('database/iruda.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id, email, name FROM users WHERE id = ?', (user_id,))
    user_data = cursor.fetchone()
    conn.close()
    
    if user_data:
        return User(user_data[0], user_data[1], user_data[2])
    return None

# 홈페이지
@app.route('/')
def home():
    return render_template('home.html')

# 회원가입 페이지
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    
    # POST 요청 처리
    data = request.form
    name = data.get('name')
    email = data.get('email')
    password = data.get('password')
    
    # 프로필 정보
    housing_status = data.get('housing_status')
    income_level = data.get('income_level')
    support_needs = data.getlist('support_needs')  # 다중 선택
    
    try:
        conn = sqlite3.connect('database/iruda.db')
        cursor = conn.cursor()
        
        # 사용자 생성
        password_hash = generate_password_hash(password)
        cursor.execute('''
            INSERT INTO users (name, email, password_hash) 
            VALUES (?, ?, ?)
        ''', (name, email, password_hash))
        
        user_id = cursor.lastrowid
        
        # 프로필 정보 저장
        cursor.execute('''
            INSERT INTO user_profiles 
            (user_id, housing_status, income_level, support_needs)
            VALUES (?, ?, ?, ?)
        ''', (user_id, housing_status, income_level, json.dumps(support_needs)))
        
        conn.commit()
        conn.close()
        
        flash('회원가입이 완료되었습니다!', 'success')
        return redirect(url_for('login'))
        
    except sqlite3.IntegrityError:
        flash('이미 존재하는 이메일입니다.', 'error')
        return render_template('register.html')

# 로그인 페이지
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    
    email = request.form.get('email')
    password = request.form.get('password')
    
    conn = sqlite3.connect('database/iruda.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id, email, name, password_hash FROM users WHERE email = ?', (email,))
    user_data = cursor.fetchone()
    conn.close()
    
    if user_data and check_password_hash(user_data[3], password):
        user = User(user_data[0], user_data[1], user_data[2])
        login_user(user)
        return redirect(url_for('dashboard'))
    else:
        flash('이메일 또는 비밀번호가 올바르지 않습니다.', 'error')
        return render_template('login.html')

# 대시보드
@app.route('/dashboard')
@login_required
def dashboard():
    # 사용자 로드맵 조회
    conn = sqlite3.connect('database/iruda.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT title, description, priority_areas, timeline 
        FROM roadmaps WHERE user_id = ? ORDER BY created_at DESC LIMIT 1
    ''', (current_user.id,))
    roadmap_data = cursor.fetchone()
    conn.close()
    
    roadmap = None
    if roadmap_data:
        roadmap = {
            'title': roadmap_data[0],
            'description': roadmap_data[1],
            'priority_areas': json.loads(roadmap_data[2]) if roadmap_data[2] else [],
            'timeline': json.loads(roadmap_data[3]) if roadmap_data[3] else {}
        }
    
    return render_template('dashboard.html', roadmap=roadmap)

# AI 로드맵 생성
@app.route('/generate-roadmap', methods=['POST'])
@login_required
def generate_roadmap():
    try:
        # 사용자 프로필 정보 가져오기
        conn = sqlite3.connect('database/iruda.db')
        cursor = conn.cursor()
        cursor.execute('''
            SELECT housing_status, income_level, support_needs 
            FROM user_profiles WHERE user_id = ?
        ''', (current_user.id,))
        profile_data = cursor.fetchone()
        
        if not profile_data:
            return jsonify({'success': False, 'error': '프로필 정보가 없습니다.'})
        
        # AI 프롬프트 생성
        support_needs = json.loads(profile_data[2]) if profile_data[2] else []
        prompt = f"""
        다음 자립준비청년을 위한 맞춤형 로드맵을 JSON 형식으로 작성해주세요:
        
        - 주거상황: {profile_data[0]}
        - 소득수준: {profile_data[1]}
        - 필요한 지원: {', '.join(support_needs)}
        
        다음 형식으로 응답해주세요:
        {{
            "title": "맞춤형 자립 로드맵",
            "description": "로드맵 설명",
            "priority_areas": ["우선순위 영역1", "우선순위 영역2"],
            "timeline": {{
                "1개월": ["할 일 1", "할 일 2"],
                "3개월": ["할 일 1", "할 일 2"],
                "6개월": ["할 일 1", "할 일 2"]
            }}
        }}
        """
        
        # OpenAI API 호출 (실제 사용시 API 키 필요)
        if openai.api_key:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "당신은 자립준비청년 전문 상담사입니다."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1500
            )
            
            roadmap_text = response.choices[0].message.content
            roadmap = json.loads(roadmap_text)
        else:
            # OpenAI API 키가 없을 때 샘플 데이터
            roadmap = {
                "title": f"{current_user.name}님의 맞춤형 자립 로드맵",
                "description": "체계적인 자립을 위한 단계별 계획입니다.",
                "priority_areas": ["주거 안정", "경제적 자립", "사회적 네트워크 구축"],
                "timeline": {
                    "1개월": ["주거급여 신청", "구직활동 시작", "자립지원센터 상담"],
                    "3개월": ["안정적 일자리 확보", "생활비 관리 시스템 구축", "멘토 찾기"],
                    "6개월": ["주거 독립 준비", "비상자금 마련", "사회보험 가입"]
                }
            }
        
        # 로드맵을 데이터베이스에 저장
        cursor.execute('''
            INSERT INTO roadmaps (user_id, title, description, priority_areas, timeline)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            current_user.id,
            roadmap['title'],
            roadmap['description'],
            json.dumps(roadmap['priority_areas']),
            json.dumps(roadmap['timeline'])
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'roadmap': roadmap})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# 정책 매칭
@app.route('/policies')
@login_required
def policies():
    conn = sqlite3.connect('database/iruda.db')
    cursor = conn.cursor()
    cursor.execute('SELECT name, category, description, application_url FROM policies WHERE is_active = 1')
    policies_data = cursor.fetchall()
    conn.close()
    
    policies = [
        {
            'name': policy[0],
            'category': policy[1],
            'description': policy[2],
            'application_url': policy[3]
        }
        for policy in policies_data
    ]
    
    return render_template('policies.html', policies=policies)

# 로그아웃
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

if __name__ == '__main__':
    # 데이터베이스 초기화
    from database.init_db import init_database
    init_database()
    
    # 앱 실행
    app.run(debug=True, host='0.0.0.0', port=5000)